#ifndef CHANGE_CASE_H
#define CHANGE_CASE_H

#include <string>
#include <cctype>
#include <iostream>

void Mayusc_minusc(const std::string& texto);

#endif