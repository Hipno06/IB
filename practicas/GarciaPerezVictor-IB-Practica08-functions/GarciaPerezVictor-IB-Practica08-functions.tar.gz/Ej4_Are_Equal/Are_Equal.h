#ifndef ARE_EQUAL_H
#define ARE_EQUAL_H

bool AreEqual(const double numero_1, const double numero_2, const double epsilon = 1e-7);

#endif