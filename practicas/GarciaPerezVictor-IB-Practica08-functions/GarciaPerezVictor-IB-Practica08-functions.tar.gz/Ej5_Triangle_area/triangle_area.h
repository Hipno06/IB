#ifndef TRIANGLE_AREA_H
#define TRIANGLE_AREA_H

bool TrianguloValido(double a, double b, double c);
double Area(double a, double b, double c);

#endif
