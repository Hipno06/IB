/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2024-2025
  *
  * @Parentheses.cc
  * @author Víctor García Pérez alu0101743387@ull.edu.es
  * @date Oct 31 2024
  * @brief Print “yes” or “no”, depending on whether the parentheses close correctly or not.
  * @bug There are no known bugs
  */

#include <iostream>
#include <string>

int main(){
  contador
  std::string; 
  std::cin >> string;
  for (char letra: string) {
    if (letra
    
  }
  return 0;
}

