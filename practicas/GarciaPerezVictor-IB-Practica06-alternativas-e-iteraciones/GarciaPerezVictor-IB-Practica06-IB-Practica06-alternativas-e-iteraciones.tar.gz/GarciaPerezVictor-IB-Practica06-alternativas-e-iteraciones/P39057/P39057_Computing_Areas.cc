/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2024-2025
  *
  * @Computing_Areas.cc
  * @author Víctor García Pérez alu0101743387@ull.edu.es
  * @date Oct 31 2024
  * @brief For each description, print its area with 6 digits after the decimal point.
  * @bug There are no known bugs
  */

#include <iostream>
#include <string>
#include <iomanip>

int main(){
  int numero{0}, numero2{0}, numero3{0};
  std::string figura;
  std::cin >> numero;
  for (i{0}; i < numero ; i++) {
    std::cin >> figura >> numero2 >> numero3;
    if (figura == "rectangle") {
      std::cout <<  
    }
  }
      
  
  }
  return 0;
}

