/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2024-2025
  *
  * @Harmonic_numbers.cc
  * @author Víctor García Pérez alu0101743387@ull.edu.es
  * @date Oct 31 2024
  * @brief Print Hn with 4 digits after the decimal point.
  * @bug There are no known bugs
  */

#include <iostream>
#include <iomanip>

int main(){
  int numero{0};
  std::cout << std::fixed << std::set
  return 0;
}

